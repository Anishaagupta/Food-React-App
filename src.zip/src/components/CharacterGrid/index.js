import React from 'react';

const CharacterGrid = () => {
  return <div>CharacterGrid</div>;
};

export default CharacterGrid;
        