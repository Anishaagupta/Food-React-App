import React from 'react';

const Spiner = () => {
  return <div>Spiner</div>;
};

export default Spiner;
        