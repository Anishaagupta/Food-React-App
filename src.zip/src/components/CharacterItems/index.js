import React from 'react';

const CharacterItems = () => {
  return <div>CharacterItems</div>;
};

export default CharacterItems;
