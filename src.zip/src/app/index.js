import React from 'react';
import Home from '../containers';

const App = () => {
  return <Home />;
};

export default App;
